opencv_version = "4.10.0+6a181ce"
contrib = False
headless = False
rolling = False
ci_build = False